
function dark() {
    document.body.style.backgroundColor = 'gray';
    
  }

function gray() {
    document.body.style.backgroundColor = 'yellow';
  }